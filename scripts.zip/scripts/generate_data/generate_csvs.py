import os
import pandas as pd
from glob import glob
from sklearn.preprocessing import StandardScaler
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from audio_utils import load_audio, save_mel_spectrogram, extract_features, split_segments

DATA_DIR = "/home/christian/Documentos/music_dataset/Data/genres_original/"
CSV_30S = "./data/csv/features_30s.csv"
CSV_3S = "./data/csv/features_3s.csv"
SR = 22050
SEGMENT_DURATION = 3   # segundos
DURATION_30S = 30      # segundos

os.makedirs("./data/csv", exist_ok=True)

all_files = []
for genre_folder in os.listdir(DATA_DIR):
    genre_path = os.path.join(DATA_DIR, genre_folder)
    if os.path.isdir(genre_path):
        wav_files = glob(os.path.join(genre_path, "*.wav"))
        all_files.extend([(f, genre_folder) for f in wav_files])

print(f"Encontrados {len(all_files)} arquivos WAV em {DATA_DIR}\n")

rows_30s = []
for idx, (file_path, genre) in enumerate(all_files, 1):
    try:
        y = load_audio(file_path, sr=SR)
        if len(y) < DURATION_30S * SR:
            print(f"Pulando {file_path}: duração menor que 30s.")
            continue
        # pega 30s centrais
        start = len(y)//2 - (DURATION_30S*SR)//2
        y = y[start:start + DURATION_30S*SR]
        feats = extract_features(y, SR)
        feats["filename"] = os.path.basename(file_path)
        feats["genre"] = genre
        rows_30s.append(feats)
        print(f"[{idx}/{len(all_files)}] OK: {file_path}")
    except Exception as e:
        print(f"Erro em {file_path}: {e}")

if rows_30s:
    df_30s = pd.DataFrame(rows_30s)
    feature_cols = [c for c in df_30s.columns if c not in ["filename", "genre"]]
    scaler = StandardScaler()
    df_30s[feature_cols] = scaler.fit_transform(df_30s[feature_cols])
    df_30s.to_csv(CSV_30S, index=False)
    print(f"\nCSV de 30s salvo em: {CSV_30S}")
else:
    print("Nenhum arquivo válido gerado para CSV de 30 segundos.\n")

rows_3s = []
for idx, (file_path, genre) in enumerate(all_files, 1):
    try:
        y = load_audio(file_path, sr=SR)
        if len(y) < DURATION_30S * SR:
            print(f"⚠️ Pulando {file_path}: duração menor que 30s.")
            continue
        # corta para os 30s centrais
        start = len(y)//2 - (DURATION_30S*SR)//2
        y = y[start:start + DURATION_30S*SR]
        # divide em blocos de 3 s
        segments = split_segments(y, SR, SEGMENT_DURATION)
        for s_idx, seg in enumerate(segments, 1):
            feats = extract_features(seg, SR)
            feats["filename"] = os.path.basename(file_path)
            feats["segment"] = s_idx
            feats["genre"] = genre
            rows_3s.append(feats)
        print(f"[{idx}/{len(all_files)}] OK: {file_path} ({len(segments)} segmentos)")
    except Exception as e:
        print(f"Erro em {file_path}: {e}")

if rows_3s:
    df_3s = pd.DataFrame(rows_3s)
    feature_cols_3s = [c for c in df_3s.columns if c not in ["filename", "segment", "genre"]]
    scaler_3s = StandardScaler()
    df_3s[feature_cols_3s] = scaler_3s.fit_transform(df_3s[feature_cols_3s])
    df_3s.to_csv(CSV_3S, index=False)
    print(f"\nCSV de 3s salvo em: {CSV_3S}")
else:
    print("Nenhum arquivo válido gerado para CSV de 3 segundos.")
